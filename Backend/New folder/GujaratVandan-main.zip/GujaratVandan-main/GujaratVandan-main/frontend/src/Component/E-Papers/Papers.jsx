import React from "react";
import "./Papers.css";
import PapersIMG from "./IMG/Papers.png";

function Papers() {
  return (
    <>
      <div className="E-Papers">
        <h1>ઈ-ન્યુઝ પેપર્સ</h1>
      </div>
      <div className="Collection">
        <div className="upload">
          <img src={PapersIMG} alt="" />
          <p>
            તારીખ:-20/08/2022 <br />
            શનિવાર
          </p>
        </div>
        <div className="upload">
          <img src={PapersIMG} alt="" />
          <p>
            તારીખ:-20/08/2022 <br />
            શનિવાર
          </p>
        </div>
        <div className="upload">
          <img src={PapersIMG} alt="" />
          <p>
            તારીખ:-20/08/2022 <br />
            શનિવાર
          </p>
        </div>
        <div className="upload">
          <img src={PapersIMG} alt="" />
          <p>
            તારીખ:-20/08/2022 <br />
            શનિવાર
          </p>
        </div>
        <div className="upload">
          <img src={PapersIMG} alt="" />
          <p>
            તારીખ:-20/08/2022 <br />
            શનિવાર
          </p>
        </div>
        <div className="upload">
          <img src={PapersIMG} alt="" />
          <p>
            તારીખ:-20/08/2022 <br />
            શનિવાર
          </p>
        </div>
        <div className="upload">
          <img src={PapersIMG} alt="" />
          <p>
            તારીખ:-20/08/2022 <br />
            શનિવાર
          </p>
        </div>
      </div>
      <div className="Collection">
        <div className="upload">
          <img src={PapersIMG} alt="" />
          <p>
            તારીખ:-20/08/2022 <br />
            શનિવાર
          </p>
        </div>
        <div className="upload">
          <img src={PapersIMG} alt="" />
          <p>
            તારીખ:-20/08/2022 <br />
            શનિવાર
          </p>
        </div>
        <div className="upload">
          <img src={PapersIMG} alt="" />
          <p>
            તારીખ:-20/08/2022 <br />
            શનિવાર
          </p>
        </div>
        <div className="upload">
          <img src={PapersIMG} alt="" />
          <p>
            તારીખ:-20/08/2022 <br />
            શનિવાર
          </p>
        </div>
        <div className="upload">
          <img src={PapersIMG} alt="" />
          <p>
            તારીખ:-20/08/2022 <br />
            શનિવાર
          </p>
        </div>
        <div className="upload">
          <img src={PapersIMG} alt="" />
          <p>
            તારીખ:-20/08/2022 <br />
            શનિવાર
          </p>
        </div>
        <div className="upload">
          <img src={PapersIMG} alt="" />
          <p>
            તારીખ:-20/08/2022 <br />
            શનિવાર
          </p>
        </div>
      </div>
    </>
  );
}

export default Papers;
